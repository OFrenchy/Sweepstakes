﻿namespace PracticeForInterview.FactoryPattern.AnotherExample
{
    public class Ice : Item
    {
    }
}