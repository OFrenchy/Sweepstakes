﻿namespace PracticeForInterview.FactoryPattern.AnotherExample
{
    public class Cup : Item
    {
        public Cup()
        {
            name = "cup";
            price = 0.70;
        }
    }
}