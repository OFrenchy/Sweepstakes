﻿namespace PracticeForInterview.FactoryPattern.AnotherExample
{
    public class Sugar : Item
    {
    }
}