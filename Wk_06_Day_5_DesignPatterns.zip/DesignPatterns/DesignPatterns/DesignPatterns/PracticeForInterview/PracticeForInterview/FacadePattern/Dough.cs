﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeForInterview.FacadePattern
{
    public class Dough
    {
        public void AddSauce(Sauce sauce)
        {

        }
        public void AddTopping(Topping topping)
        {

        }
        public void AddCheese(Cheese cheese)
        {

        }
    }
}
