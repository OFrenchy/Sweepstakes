﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeForInterview.FacadePattern
{
    public class Oven
    {
        public void SetTemperature(int temperature)
        {

        }
        public void SetTimer(double minutes)
        {

        }
        public void Cook(Dough dough)
        {

        }
    }
}
