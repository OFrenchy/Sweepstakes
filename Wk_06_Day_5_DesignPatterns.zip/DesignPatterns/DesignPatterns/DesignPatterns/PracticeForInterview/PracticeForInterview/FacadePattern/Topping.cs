﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeForInterview.FacadePattern
{
    public class Topping
    {
        private string topping;
        public Topping(string topping)
        {
            this.topping = topping;
        }
    }
}
