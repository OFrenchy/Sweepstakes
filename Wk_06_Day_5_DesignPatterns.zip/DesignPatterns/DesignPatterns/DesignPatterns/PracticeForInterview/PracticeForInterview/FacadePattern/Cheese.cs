﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeForInterview.FacadePattern
{
    public class Cheese
    {
        private string cheese;
        public Cheese(string cheese)
        {
            this.cheese = cheese;
        }
    }
}
