﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeForInterview.FacadePattern
{
    public class Sauce
    {
        private string sauce;
        public Sauce(string sauce)
        {
            this.sauce = sauce;
        }
    }
}
